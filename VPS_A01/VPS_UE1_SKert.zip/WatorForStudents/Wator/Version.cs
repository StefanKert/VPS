namespace VSS.Wator {
    public enum Version
    {
        DummyWatorWorld,
        OriginalWatorWorld,
        OptimizedWatorWorld
    }
}
